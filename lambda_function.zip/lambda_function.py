import random

def lambda_handler(event, context):
    # Número pensado pela máquina
    numero_secreto = random.randint(1, 10)
    
    # Obtendo o palpite
    palpite = int(event['queryStringParameters']['palpite'])
    
    # Verificando o palpite
    if palpite < numero_secreto:
        resposta = "O número é maior. Tente novamente!"
    elif palpite > numero_secreto:
        resposta = "O número é menor. Tente novamente!"
    else:
        resposta = f"Parabéns! Você acertou o número {numero_secreto}!"
    
    # Retornando a resposta
    return {
        'statusCode': 200,
        'body': f'{{"resultado": "{resposta}"}}'
    }